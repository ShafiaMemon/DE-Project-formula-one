# Databricks notebook source
raw_folder_path = "/mnt/datalformulaone/raw"
processed_folder_path = "/mnt/datalformulaone/processed"
presentation_folder_path = "/mnt/datalformulaone/presentation"